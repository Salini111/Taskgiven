package com.task;

public class AllExceptionEx {

	

	public int Arithmatic(int a,int b)
	{
		return a/b;
	}
}