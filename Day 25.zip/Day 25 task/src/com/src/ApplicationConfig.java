package com.src;


import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import org.springframework.context.annotation.Bean;



public class ApplicationConfig {
	
@Bean(name="cset")
	public Customer getCustomer()
{
	Customer c=new Customer();
	c.setCid("c1");
	c.setCname("salini");
	c.setCmob(93424242);
	return c;
	}
@Bean(name="csetobj")
public Customer getCustomer1()
{
	Customer c=new Customer();
	c.setCid("c2");
	c.setCname("manju");
	c.setCmob(98434343);
	Address ad=new Address();
	ad.setHno(12);
	ad.setCity("dpm");
	c.setAdd(ad);
	return c;
	}
@Bean(name="setlist")
public Customer getCustomer2()
{
	Customer c=new Customer();
	c.setCid("c1");
	c.setCname("mohan");
	c.setCmob(98525252);
	List<Item> i1=new LinkedList();
	Item a1=new Item();
	a1.setItemId(1);
	a1.setItemName("fan");
	a1.setItemPrice(2000);
	i1.add(a1);
	
	Item a2=new Item();
	a2.setItemId(1);
	a2.setItemName("fan");
	a2.setItemPrice(2000);
	i1.add(a2);
	c.setItem(i1);
	return c;



}
@Bean(name="conslist")
public Customer getCustomer5()
{
	Customer c=new Customer();
	c.setCid("c5");
	c.setCname("manoj");
	c.setCmob(63636363);
	List<Item> a=new LinkedList();
	a.add(new Item(1,"mixy",5000));
	a.add(new Item(2,"Grinder",2000));
	c.setItem(a);
	return c;
	
}
@Bean(name="cons")
public Customer getCustomer3()
{
	return new Customer("c100","paapu",98765);	
}
@Bean(name="consobj")
public Customer getCustomer4()
{
	return new Customer("c200","preethi",8765,new Address(150,"pars"));	
}












}

