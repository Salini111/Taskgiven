package com.src;

import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class EmployeeLoginServlet
 */
@WebServlet("/EmployeeLoginServlet")
public class EmployeeLoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EmployeeLoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 String u=request.getParameter("uname");
		 String p=request.getParameter("pwd");
	   DBConnection db=new DBConnection();
	   
	   String sql="select * from authendication where eid=? and epassword=?";
	   try {
		PreparedStatement ps=db.getMyprepStatement(sql);
	
	ps.setString(1, u);   
	ps.setString(2, p);   
	ResultSet rs=ps.executeQuery();
	String message;
	if(rs.next())
	{  Cookie ck=new Cookie("user",u);
	response.addCookie(ck);
		message="sucessfully";
		response.sendRedirect("Profile.jsp?msg="+message);
	}else
	{
		message="Invalid username and password";
		response.sendRedirect("index.jsp?msg="+message);
	}
	
	
	
	
	
	
	   } catch (ClassNotFoundException | SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	   
	}
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
