package com.src;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

public class DBConnection {

	Connection con;
	 Statement st;
	 PreparedStatement ps;
	 
	 
	 public Statement getMyStatement()
	 {


				try {
					Class.forName("com.mysql.cj.jdbc.Driver");
					String url="jdbc:mysql://localhost:3306/employe";
					String user="root";
						String password="root";
					con=DriverManager.getConnection(url,user,password);
				 st=con.createStatement();
				
				} catch (ClassNotFoundException | SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		
		return st;
		 
	 }
	 public PreparedStatement getMyprepStatement(String sql) throws ClassNotFoundException {
			
			try {
				Class.forName("com.mysql.cj.jdbc.Driver");
				String url="jdbc:mysql://localhost:3306/employe";
				String username="root";
				String password="root";
				con=DriverManager.getConnection(url, username, password);
				ps=con.prepareStatement(sql);
				
				} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return ps;
			}
	 
	 
	 
	 
}
